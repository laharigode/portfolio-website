import Link from 'next/link'
import Image from "next/image"

export default function CoverImage({ title, url, slug }) {
  const image = (
    <Image
      src={url}
      alt={`Cover Image for ${title}`}
      width={1920}
      height={1080}
      sizes="100vw"
      style={{
        width: "100%",
        height: "auto"
      }} />
  )
  return (
    <div className="sm:mx-0">
      {slug ? (
        <Link as={`/posts/${slug}`} href="/posts/[slug]" aria-label={title}>
          {image}
        </Link>
      ) : (
        image
      )}
    </div>
  )
}
