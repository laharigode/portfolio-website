const navButtons = [
  {
    label: 'Portfolio',
    path: '/',
  },
  {
    label: 'Writings',
    path: '/writings',
  },
]

export default navButtons
