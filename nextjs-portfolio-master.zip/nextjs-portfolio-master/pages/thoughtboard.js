import PageLayout from '@/components/page-layout'

export default function MasonryGridTwitter() {
  return (
    <PageLayout>
      <div>Thoughtboard</div>
    </PageLayout>
  )
}
