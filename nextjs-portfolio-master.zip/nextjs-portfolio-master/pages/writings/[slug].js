import { useRouter } from 'next/router'
import ErrorPage from 'next/error'
import PostBody from '@/components/post-body'
import PostHeader from '@/components/post-header'
import PageLayout from '@/components/page-layout'
import { getAllPostsWithSlug, getSinglePost } from '@/lib/api'

import Head from 'next/head'
import markdownToHtml from '@/lib/markdownToHtml'

export default function Post({ post, preview }) {
  const router = useRouter()
  if (!router.isFallback && !post?.slug) {
    return <ErrorPage statusCode={404} />
  }

  return (
    <PageLayout preview={preview}>
      {router.isFallback ? (
        <h1 className="page-title-design">Loading…</h1>
      ) : (
        <>
          <article>
            <Head>
              <title>{post.title}</title>
              <meta
                property="og:image"
                content={post.metadata.cover_image.imgix_url}
              />
              <meta property="og:description" content={post.metadata.excerpt} />
              <meta name="description" content={post.metadata.excerpt} />
              <meta name="twitter:card" content="summary_large_image" />
              <meta name="twitter:site" content="@shreyasjpg" />
              <meta name="twitter:title" content={post.title} />
              <meta
                name="twitter:description"
                content={post.metadata.excerpt}
              />
              <meta
                name="twitter:image"
                content={post.metadata.cover_image.imgix_url}
              />
            </Head>
            <PostHeader
              title={post.title}
              coverImage={post.metadata.cover_image}
              date={post.created_at}
              excerpt={post.metadata.excerpt}
              content={post.markdown}
            />
            <PostBody content={post.content} />
          </article>
          <div className="mx-4 lg:mx-8">
            <hr
              className="mt-16 mb-8 md:mb-24 md:mt-28 border-1 border-neutral-800"
              aria-hidden="true"
            />
          </div>

          {/* {morePosts.length > 0 && <MoreStories posts={morePosts} />} */}
        </>
      )}
    </PageLayout>
  )
}

export async function getStaticProps({ params, preview = null }) {
  const data = await getSinglePost(params.slug)
  const content = await markdownToHtml(data.metadata?.content || '')
  const markdown = data.metadata?.content || ''
  return {
    props: {
      preview,
      post: {
        ...data,
        content,
        markdown,
      },
      morePosts: data.morePosts || [],
    },
  }
}

export async function getStaticPaths() {
  const allPosts = (await getAllPostsWithSlug()) || []
  return {
    paths: allPosts.map((post) => `/writings/${post.slug}`),
    fallback: true,
  }
}
